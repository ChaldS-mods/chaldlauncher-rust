use std::io::Read;
use std::path::{Path, PathBuf};

use sha1::{Digest, Sha1};
use sha2::Sha256;
use tokio::io::AsyncWriteExt;

use crate::errors::{AppError, AppResult};
use crate::net::net_request;

#[derive(Debug, Clone)]
pub struct DownloadSpec {
    pub url: String,
    pub dest: PathBuf,
    pub sha1: Option<String>,
    pub sha256: Option<String>,
    pub size: Option<u64>,
    pub purpose: String,
}

fn hex(bytes: &[u8]) -> String {
    let mut out = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        out.push_str(&format!("{byte:02x}"));
    }
    out
}

pub fn hash_file(path: &Path, algo: &str) -> AppResult<String> {
    let mut file = std::fs::File::open(path)?;
    let mut buffer = [0u8; 64 * 1024];
    if algo == "sha1" {
        let mut hasher = Sha1::new();
        loop {
            let read = file.read(&mut buffer)?;
            if read == 0 {
                break;
            }
            hasher.update(&buffer[..read]);
        }
        Ok(hex(&hasher.finalize()))
    } else {
        let mut hasher = Sha256::new();
        loop {
            let read = file.read(&mut buffer)?;
            if read == 0 {
                break;
            }
            hasher.update(&buffer[..read]);
        }
        Ok(hex(&hasher.finalize()))
    }
}

/// True when the file exists and matches every check we know about.
pub fn is_file_valid(path: &Path, size: Option<u64>, sha1: Option<&str>, sha256: Option<&str>) -> bool {
    let Ok(metadata) = std::fs::metadata(path) else { return false };
    if !metadata.is_file() {
        return false;
    }
    if let Some(size) = size {
        if metadata.len() != size {
            return false;
        }
    }
    if let Some(expected) = sha1 {
        if hash_file(path, "sha1").ok().as_deref() != Some(expected) {
            return false;
        }
    }
    if let Some(expected) = sha256 {
        if hash_file(path, "sha256").ok().as_deref() != Some(expected) {
            return false;
        }
    }
    true
}

fn temp_path(dest: &Path) -> PathBuf {
    let mut name = dest
        .file_name()
        .map(|name| name.to_os_string())
        .unwrap_or_default();
    name.push(".part");
    dest.with_file_name(name)
}

pub async fn download_file(spec: &DownloadSpec, mut on_bytes: impl FnMut(u64)) -> AppResult<()> {
    if is_file_valid(&spec.dest, spec.size, spec.sha1.as_deref(), spec.sha256.as_deref()) {
        if let Ok(metadata) = std::fs::metadata(&spec.dest) {
            on_bytes(metadata.len());
        }
        return Ok(());
    }
    if let Some(parent) = spec.dest.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }
    let temp = temp_path(&spec.dest);
    let result = write_download(spec, &temp, &mut on_bytes).await;
    match result {
        Ok(()) => {
            tokio::fs::rename(&temp, &spec.dest).await?;
            Ok(())
        }
        Err(error) => {
            let _ = tokio::fs::remove_file(&temp).await;
            Err(error)
        }
    }
}

async fn write_download(
    spec: &DownloadSpec,
    temp: &Path,
    on_bytes: &mut impl FnMut(u64),
) -> AppResult<()> {
    let crate::net::NetResponse { mut response, url } = net_request(&spec.url, &spec.purpose).await?;
    if !response.status().is_success() {
        return Err(AppError::new(
            "HTTP_ERROR",
            format!("HTTP {} от {}", response.status().as_u16(), url.host_str().unwrap_or("")),
        ));
    }
    if let Some(expected) = spec.size {
        if let Some(length) = response.content_length() {
            if length != expected {
                return Err(AppError::new(
                    "DOWNLOAD_SIZE",
                    format!("Неверный размер файла: ожидался {expected}, сервер отдаёт {length}"),
                ));
            }
        }
    }

    let mut file = tokio::fs::File::create(temp).await?;
    let mut sha1_hasher = Sha1::new();
    let mut sha256_hasher = Sha256::new();
    let mut written: u64 = 0;
    while let Some(chunk) = response
        .chunk()
        .await
        .map_err(|e| AppError::new("NET_FAILED", format!("Соединение прервано: {e}")))?
    {
        written += chunk.len() as u64;
        if let Some(size) = spec.size {
            if written > size {
                return Err(AppError::new("DOWNLOAD_SIZE", "Файл больше заявленного размера"));
            }
        }
        sha1_hasher.update(&chunk);
        sha256_hasher.update(&chunk);
        file.write_all(&chunk).await?;
        on_bytes(chunk.len() as u64);
    }
    file.flush().await?;
    drop(file);

    if let Some(size) = spec.size {
        if written != size {
            return Err(AppError::new("DOWNLOAD_SIZE", "Файл скачался не полностью"));
        }
    }
    if let Some(expected) = &spec.sha1 {
        if &hex(&sha1_hasher.finalize()) != expected {
            return Err(AppError::new("DOWNLOAD_HASH", "Файл повреждён (SHA-1 не совпал)"));
        }
    }
    if let Some(expected) = &spec.sha256 {
        if &hex(&sha256_hasher.finalize()) != expected {
            return Err(AppError::new("DOWNLOAD_HASH", "Файл повреждён (SHA-256 не совпал)"));
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hashes_and_size_checks() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("a.txt");
        std::fs::write(&file, b"hello").unwrap();
        assert_eq!(hash_file(&file, "sha1").unwrap(), "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d");
        assert!(is_file_valid(&file, Some(5), Some("aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"), None));
        assert!(!is_file_valid(&file, Some(6), None, None));
        assert!(!is_file_valid(&file, None, Some("0".repeat(40).as_str()), None));
        assert!(!is_file_valid(&dir.path().join("missing"), None, None, None));
    }
}
